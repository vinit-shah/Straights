#include <iostream>
#include <vector>

#include "Game.h"

int main()
{

  Game game;
  game.startGame();
  game.play();
}
